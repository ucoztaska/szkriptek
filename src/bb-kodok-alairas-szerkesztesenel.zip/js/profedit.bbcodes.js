function bbCode(tg, param) {
	$("#blocksize").fadeOut(100);
	var o = '[' + tg + (param ? ("=" + param) : "") + ']',
	c = '[/' + tg + ']',
	doc = $('#siF9')[0];
	doc.focus();
	if (window.attachEvent && navigator.userAgent.indexOf('Opera') === -1) {
		var s = doc.sel;
		if (s) {
			var l = s.text.length;
			s.text = o + s.text + c;
			s.moveEnd("character", -c.length);
			s.moveStart("character", -l);
			s.select();
		}
	} else {
		var ss = doc.scrollTop;
		sel1 = doc.value.substr(0, doc.selectionStart);
		sel2 = doc.value.substr(doc.selectionEnd);
		sel = doc.value.substr(doc.selectionStart, doc.selectionEnd - doc.selectionStart);
		doc.value = sel1 + o + sel + c + sel2;
		doc.selectionStart = sel1.length + o.length;
		doc.selectionEnd = doc.selectionStart + sel.length;
		doc.scrollTop = ss;
	};
	return false;
}

function _tag_url(wh){
var enterURL  = prompt('Add meg az URL-c�met', "http://");
var enterTITLE=isSelected(wh);
if (enterTITLE.length==0){
    enterTITLE = prompt('Add meg a megjelen� sz�veget',"");      
}
if (!enterURL || enterURL=='http://'){
    return;
}
else if (!enterTITLE) {
    return;
}

doInsert('<a href="'+enterURL+'" target="_blank">'+enterTITLE+'</a>',"",false,wh);  
}