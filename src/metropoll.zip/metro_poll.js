for(var i = 0; i < 22; i++){
$('div.answer').eq(i).addClass('bb'+i);
$('div.answer div').eq(i).addClass('progress');
$('div.answer div div').eq(i).addClass('progress'+i).css({marginTop: '-3px', marginBottom: '-3px',backgroundRepeat: 'repeat-x'});}
for(var e = 0; e < 15; e++){
$('div.bb'+e+' span').each(function(){
var aaa = $(this).attr('title').split('%)')[0];
var bbb = aaa.split('(')[1];
$(this).html($(this).html()+' - <span class="procent">'+$(this).attr('title').split(':')[1]+'</span><style>.bb'+e+' div div{width: '+bbb+'% !important;}</style>');
}); 
}