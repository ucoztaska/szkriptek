﻿/*
       CTM - Complaint the material. Жалоба на материал
    -------------------------------------------------------
                      2013 (c) by uMk0
                   http://web.reslear.ru/

*/
function startCTM() {
    for (var a = "", b = 0; b <= ctmarray.length - 1; b++) {
        var c = "";
        b != ctmarray.length - 1 && (c = "<hr>");
        a = a + '<div style="margin:5px"><input id="ctm' + b + '" onclick="ctmclick();" type="radio" name="answer" value="' + b + '" style="vertical-align:middle;"> <label style="vertical-align:middle;display:inline;width:100%" id="ctmrext' + b + '" for="ctm' + b + '">' + ctmarray[b].ctm[0] + "</label></div>" + c
    }
    b = _uButton(null, "button", {
        style: 1,
        text: "Küldés",
        content: 'id="ctmaddbtn" onclick="ctmget()"'
    });
    new _uWnd("ctm", "Жалоба на материал", 0, 0, {
        autosize: 1,
        notaskbar: 1,
        fadetype: 2,
        fadespeed: 500,
        fadeclosetype: 1,
        fadeclosespeed: 500,
        align: "left"
    }, '<fieldset style="margin-top:5px;padding-bottom:5px;"><legend>Válaszd ki a jelentés formáját</legend>' + a + '</fieldset><fieldset><div id="ctminput" style="display:none;float:left"></div><div style="float:right;padding-top:3px;margin-top:3px;margin-bottom:6px;" id="ctmadd">' + b + "</div></fieldset>")
}

function ctmclick() {
    $("#ctminput").stop().slideUp();
    $("#ctminp").val("");
    var a = $("input:checked").val();
    if (ctmarray[a].ctm[1]) {
        var b = ctmarray[a].ctm[2];
        b || (b = "");
        $("#ctminput").html("<input style='width:200px;margin-top:6px' placeholder='" + b + "' id='ctminp' type='text'>").stop().slideDown()
    }
    $("#ctmaddbtn").attr("ctmval", a);
    $("#ctmaddbtn").removeAttr("onclick").attr("onclick", 'ctmget("' + a + '");')
}

function ctmget(a) {
    if (void 0 == a) {
        _uWnd.alert("<font color=#971111><br><br>Nem választottál ki semmit!</font>", "", {
            w: 270,
            h: 90,
            tm: 5E3,
            align: "center"
        })
    } else {
        var b = ($("#ctminp").val() ? ctmtmp[0] + ctmtmp[1] : ctmtmp[0]).replace(/{URL}/g, document.location.href).replace(/{TITLE}/g, $("title").html()).replace(/{MOAN_MESSAGE}/g, $("#ctmrext" + a + "").html()).replace(/{EXTRA_MESSAGE}/g, $("#ctminp").val()).replace(/"/g, "&quot;");
        $.get("/index/14-0-0-1", function(a) {
            var d = $('input[name="ssid"]', a).val(),
                e = $("#secuImg", a).attr("src"),
                f = $("#secuImg", a).attr("onclick");
            a = $('input[name="seckey"]', a).val();
            void 0 == e ? postCTM(b, a, d) : (d = _uButton(null, "button", {
                style: 1,
                text: "Ок",
                content: "onclick=\"postCTM('" + b + "','" + a + "','" + d + "')\""
            }), new _uWnd("ctmSECkey", "", 0, 0, {
                header: 0,
                autosizeonimages: 1,
                notaskbar: 1,
                fadetype: 2,
                fadespeed: 500,
                fadeclosetype: 1,
                fadeclosespeed: 500,
                align: "left"
            }, '<fieldset style="margin-top:5px;padding-bottom:5px;"><legend>Írd be a biztonsági kódot</legend><table><td><img src="' + e + '" onclick="' + f + '" title="Biztonsági kód frissítése" id="CTMsecuImg" style="cursor:pointer"></td><td><input size="7" id="CTMsecuCode" maxlength="6" placeholder="Kód" style="padding:6px;font-size:20px;"></td><td>' + d + "</td></fieldset>"))
        })
    }
}

function postCTM(a, b, c) {
    $("#ctmadd").html("<div class='myWinLoadS'></div>");
    $.post("/index/", {
        a: 18,
        s: username,
        subject: "Anyag jelentése",
        ssid: c,
        seckey: b,
        code: $("#CTMsecuCode").val(),
        message: a
    }, function(a) {
        -1 < $(a).text().indexOf("sikeres") ? (_uWnd.close("ctmSECkey"), _uWnd.alert('<br><font color=green>Jelentés elküldve <img src="http://s86.ucoz.net/sm/1/happy.gif"></font>', "", {
            tm: 4E3,
            w: 240,
            h: 77
        }), $("#ctmadd").html("<div class='myWinLoadSD'></div>"), setTimeout('_uWnd.close("ctm")', 1500)) : -1 < $(a).text().indexOf("код") ? (_uWnd.alert('<br><div id="errorcmt">' + $('cmd[p="innerHTML"]', a).text() + "</div><style>#errorcmt hr{display:none}</style>", "Hiba", {
            tm: 4E3,
            w: 240,
            h: 90
        }), $("#CTMsecuImg").click(), $("#CTMsecuCode").val("")) : (_uWnd.close("ctm"), _uWnd.close("ctmSECkey"), $("#CTMsecuImg").click(), $("#CTMsecuCode").val(""), _uWnd.alert('<br><div id="errorcmt">' + $('cmd[p="innerHTML"]', a).text() + "</div><style>#errorcmt hr{display:none}</style>", "Hiba", {
            tm: 4E3,
            w: 300,
            h: 90
        }))
    })
}