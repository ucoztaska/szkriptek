$.get('/index/9-'+user_id+'-1', function(data){
conts = $('cmd[p="content"]', data).text();
$("#editRep").html( $('td[nowrap="nowrap"]', conts).next().next().find('div').html() );
$("#editRep").find("img").css({'height' : '10px', 'width' : '10px', 'margin-left' : '2px'});
$("#editRep").find('a:first img').attr({'src' : '/usrep/icon_edit.png'});
$("#editRep").find('a:eq(1) img').attr({'src' : '/usrep/icon_out.png'});
$("#editRep").find('a:eq(2) img').attr({'src' : '/usrep/icon_delete.png'});
$("#testRepa").html( $('div[id^="blr"]:first', conts).parent('div').html() );
$("#testRepa").find('hr:last').hide();
$("#scriptRep").html( eval($('cmd[p="js"]', data).text()) );

$("#testRepa").find('a.pgSwch').each(function(){
var nPage = $(this).text();
$(this).removeAttr('onclick').attr({href: 'javascript:oddRep('+nPage+')'});
});

});

function oddRep(nPage){
$.get('/index/9-'+user_id+'-' + nPage, function(datas){
conts = $('cmd[p="content"]', datas).text();
$("#testRepa").html( $('div[id^="blr"]:first', conts).parent('div').html() );
$("#testRepa").find('hr:last').hide();
$("#scriptRep").html( eval($('cmd[p="js"]', datas).text()) );

$("#testRepa").find('a.pgSwch').each(function(){
var nPage = $(this).text(); 
$(this).removeAttr('onclick').attr({href: 'javascript:oddRep('+nPage+')'});
});

});
};