﻿    /*
          Смена персонального Аватара
          by ReSLeaR- (c) 2013
    */
var uAvatar = {
    replace: function(url){
        window.history.replaceState('','',url);
        return 1;
    },
    sel: function(t){
        $('#uava_url').val($('img',t).attr('src'));
        $('#ava_uimgaga a').removeAttr('style');
        $(t).attr('style','opacity:1');
    },
    get :function(url){
        var a;
        $.ajax({url:url,async:0}).done(function(x){
            a = x;
        });
        return a;
    },
    _getrandomavatar: function(){
        var self = this, urls = [];
        self.rand = function(mss){
            return mss[Math.floor(Math.random()*mss.length)];
        }
        $('a',self.get('/index/7-1')).each(function(){
            urls.push($(this).attr('href'));
        }).promise().done(function(){
            var resp = self.get(self.rand(urls)), images = '';
            $('img',resp).each(function(i){
                if(i == 16) return false;
                images += '<a href="javascript://" onclick="uAvatar.sel(this)" title="Kattintson az avatar kiválasztásához!"><img src="'+$(this).attr('src')+'" width="30" height="30"/></a>';
            }).promise().done(function(){
                $('#ava_uimgaga').hide().html('<div style="text-align:center">'+images+'</div>').fadeIn(300);
            });
        });
    },
    _recap: function(s){
        $.get('/index/11',function(k){
            $('#secassexxx').html($('#siM62',k).html());
            if(s) $('#uava_urlk').val($('#siF12',k).val());
        });
    },
    serialize: function(){
        var self = this, formdata = {}, each;
        $('input[name]',self.get('/index/11')).each(function(){
            var t = $(this), n = t.attr('name');
            if(n == 'avatar' || n == 'avau' || n == 'code' || n == 'seckey') return; else formdata[n] = t.val();
        }).promise().done(function(){
            JSON.stringify(formdata);
            each = 1;
        });
        return each ? formdata : 0;
    },
    alert: function(text){
        _uWnd.alert('<br>'+text,'Avatar megváltoztatása',{close:1,w:250,h:80,tm:3000,align:'center'});
    },
    anim:function(obj,h){
        h = h ? 'hide' : 'show';
        $(obj).stop().animate({opacity:h,height:h},300);
    },
    post: function(){
        var self = this, docl = document.location, url = docl.protocol+"//"+docl.hostname+docl.pathname;
        if($('.securityCode').val().length == 0){
            self.alert('Adja meg a biztonsági kódot');
            self.anim('#secassexxx');
            self.rsize();
            return false;
        }
        $('#avaggagag-status').html('<div class="myWinLoadS" style="display-block;margin-left:5px"></div>');
        if(self.replace('/index/11')){
            _uPostForm($("#u_ava"),{
                url:'/index/',
                type:'post',
                data: self.serialize(),
                complete: function(x){
                    $('#avaggagag-status').html('');
                    var r = x.responseText, eror = $('#siM2',r).html() ? 1 :0;
                    self.alert(eror ? $('#siM2',r).html() : 'Avatar sikeresen megváltoztatva!');
                    self._recap();
                    if(!eror){
                        $.get('/index/8',function(s){
                            var uhrl = $('#uavaimager img',s).attr('src')
                            $('#uavaimager img').attr('src',uhrl);
                            $($('#uavatar-link').attr('replid')).attr('src',uhrl);
                        });
                    }
                    if(eror) self.anim('#secassexxx',1);
                }
            });
            self.replace(url);
        }
    },
    rsize: function(){
        setTimeout(function(){
            _uWnd.getbyname('uavagtt').checksize();
        },300);
    },
    fill: function(i){
        var self = this;
        if(i){
            self.anim('#uava_urlk');
            self.anim('#uava_file',1);
            $('#uavai').html('');
        }else{
            self.anim('#uava_urlk',1);
            self.anim('#uava_file');
            $('#uavai').html('<input type="file" name="avau" id="avau" style="width:100%;">');
        }
        self.rsize();
    },
    _uwnd: function(){
        var self = this, addbutton = _uButton(null, 'button',{ext:1,text:'Kész!',content: 'onclick="uAvatar.post()" id="postuava1"'});
        new _uWnd('uavagtt','Avatar megváltoztatása',380,270,{autosize:0,resize:0,notaskbar:1,fadetype:2,fadespeed:200,fadeclosetype:1,fadeclosespeed:500,align:'left',oncontent:function(){
            self._getrandomavatar();
            self._recap(1);
            self.rsize();
        }},'<form id="u_ava" style="margin:0;padding:0"><style>#secassexxx img{height:30px;opacity:.6}#secassexxx input{height:26px;width:90px;font: 18px Tahoma}#ava_uimgaga a{padding-right:5px;opacity:.4;}#ava_uimgaga a:hover{opacity:1;cursor:pointer;}</style><fieldset id="uava_urlk" style="margin-top:5px;padding:5px 10px 5px 5px;"><legend>URL-cím</legend><input type="text" name="avatar" id="uava_url" style="width:100%;padding-right:0;margin-right:0"><div id="ava_uimgaga" style="padding-top: 5px"></div><div style="color:gray;padding: 5px 0"><a href="javascript://" onclick="uAvatar._getrandomavatar()" style="float:right">Több generálása</a><div>Saját avatar <a href="javascript://" style="color:gray" onclick="uAvatar.fill()">feltöltése</a></div> </div></fieldset><fieldset style="padding:5px 10px 5px 5px;display:none;" id="uava_file"><legend>Új avatar feltöltése</legend><div id="uavai"></div><div style="color:gray;padding: 5px 0">Vissza <a href="javascript://" style="color:gray" onclick="uAvatar.fill(1)">Avatar kiválasztása</a></div></fieldset><fieldset style="padding:5px 10px 5px 5px;text-align:center;display:none;" id="secassexxx"></fieldset><fieldset style="padding:5px 10px 5px 5px;">'+addbutton+'<span id="avaggagag-status"></span></fieldset></form>');
    }
}
